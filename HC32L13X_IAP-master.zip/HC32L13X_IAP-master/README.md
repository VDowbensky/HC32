# HDSC_HC32L13X

#### 介绍

基于华大MCU的低功耗系列MCU的一系列应用，持续更新中。这个是基于老的驱动库的，新的驱动库见我的另一个开源仓库中。

#### 官网资料：

STEP1, 打开【我的电脑】或浏览器，在地址栏输入地址  ftp://HdscCustomer:HdscGuest2019!@ftp.hdsc.com.cn/

STEP2, 按下【回车】，即可像操作本地文件一样进行操作；（注：使用谷歌或火狐可能会产生乱码）

如果使用FTP客户端，请使用如下参数。
    URL:  ftp.hdsc.com.cn
    User: HdscCustomer
    Psw:  HdscGuest2019!  
    Port:  21

#### 硬件信息

1.  Base on hdsc 136 demo board 

#### 软件开发环境

1.  MDK5

#### 软件模块运行结果
1. IAP_Ymodem_demo
![输入图片说明](https://images.gitee.com/uploads/images/2019/1204/162233_82e46044_4987101.png "图片1.png")

#### 参与贡献

1.  Fork 本仓库
2.  新建 Feat_xxx 分支
3.  提交代码
4.  新建 Pull Request


#### 码云特技

1.  使用 Readme\_XXX.md 来支持不同的语言，例如 Readme\_en.md, Readme\_zh.md
2.  码云官方博客 [blog.gitee.com](https://blog.gitee.com)
3.  你可以 [https://gitee.com/explore](https://gitee.com/explore) 这个地址来了解码云上的优秀开源项目
4.  [GVP](https://gitee.com/gvp) 全称是码云最有价值开源项目，是码云综合评定出的优秀开源项目
5.  码云官方提供的使用手册 [https://gitee.com/help](https://gitee.com/help)
6.  码云封面人物是一档用来展示码云会员风采的栏目 [https://gitee.com/gitee-stars/](https://gitee.com/gitee-stars/)
