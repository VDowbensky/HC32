#ifndef __YMODEM__H_
#define __YMODEM__H_

#include "flash_update.h"
#include "uart.h"
#include <stdio.h>

//配置定义参数
#define	YMODEM_RECV_ENABLE 		1
#define	YMODEM_SEND_ENABLE 		1
#define	FLASH_PAGE_SIZE 		512

#define	FILE_NAME_LENGTH 		64
#define	FILE_SIZE_LENGTH 		16

#define NAK_TIMEOUT             (1000)		//最大超时时间	1s
#define MAX_ERRORS              (5)			//错误上限

//常量宏定义
#define PACKET_SEQNO_INDEX      (1)			//数据包序号
#define PACKET_SEQNO_COMP_INDEX (2)			//包序取反

#define PACKET_HEADER           (3)			//首部3位
#define PACKET_TRAILER          (2)			//CRC检验的2位
#define PACKET_OVERHEAD         (PACKET_HEADER + PACKET_TRAILER)//3位首部+2位CRC
#define PACKET_SIZE             (128)		//128字节
#define PACKET_1K_SIZE          (1024)		//1024字节

#define SOH                     (0x01)		//128字节数据包开始
#define STX                     (0x02)		//1024字节的数据包开始
#define EOT                     (0x04)		//结束传输
#define ACK                     (0x06)		//回应
#define NAK                     (0x15)		//没回应
#define CA                      (0x18)		//这两个相继中止转移
#define CRC16                   (0x43)		//'C'即0x43, 需要 16-bit CRC 

#define ABORT1                  (0x41)		//'A'即0x41, 用户终止 
#define ABORT2                  (0x61)		//'a'即0x61, 用户终止

extern unsigned char YModem_RecvByte(unsigned char *c, unsigned int ms);
extern void YModem_SendByte(unsigned char c);
extern void YModem_SendStr(unsigned char *str);

extern unsigned int W_CRC16(unsigned char *ptr, unsigned int len) ;
extern int w_atoi (char *s);

extern int 	YModem_Receive_Proc(unsigned char *buf, unsigned int *length);
extern int	YModem_Transmit(unsigned char *buf,unsigned  char *sendFileName, unsigned int fileSize);

extern unsigned  char  		file_name[];
extern unsigned  char  		file_size[];
extern unsigned  char  		packet_data[]; 

#endif 	//__YMODEM__H_

