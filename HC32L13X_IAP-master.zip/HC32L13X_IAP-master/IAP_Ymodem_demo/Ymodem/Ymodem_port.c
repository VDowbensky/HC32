
#include "Ymodem.h"
#include "bsp_uart.h"
#include "iap.h"


#if		(YMODEM_RECV_ENABLE == 1) || (YMODEM_SEND_ENABLE == 1)

unsigned char  		file_name[FILE_NAME_LENGTH];
unsigned char  		file_size[FILE_SIZE_LENGTH];
unsigned char  		packet_data[PACKET_1K_SIZE + PACKET_OVERHEAD]; 


/*** 以下三个接口来自于uart驱动  ，移植的时候需要修改**/


/*************************************************************
  Function   : YModem_RecvByte 
  Description: ymodem接收一个字节
  Input      : c-存放接收到的字节 ms-超时时间        
  return     : none    
*************************************************************/
unsigned char YModem_RecvByte(unsigned char *c, unsigned int ms)
{
	uint8_t		ch;
	while(ms--)
	{
#ifdef IAP_COM_UART0
		if(Hal_Uart0_Recv(&ch) == 0)
#endif
#ifdef IAP_COM_LPUART0
		if(Hal_LPUart0_Recv(&ch) == 0)
#endif			
		{
			*c = ch;
			return 0;
		}
	}
	return 1;	//超时
}

/*************************************************************
  Function   : YModem_SendByte 
  Description: 发送一个字节
  Input      : c-要发送的字节        
  return     : none    
*************************************************************/
void YModem_SendByte(unsigned char c)
{
#ifdef IAP_COM_UART0
	Hal_Uart0_Send(c);
#endif
#ifdef IAP_COM_LPUART0
	Hal_LPUart0_Send(c);	
#endif
}

void YModem_SendStr(unsigned char *str)
{
#ifdef IAP_COM_UART0
	Hal_Uart0_Send_Str(str);
#endif
#ifdef IAP_COM_LPUART0
	Hal_LPUart0_Send_Str(str);	
#endif

}



unsigned int W_CRC16(unsigned char *ptr, unsigned int len)  
{ 
    unsigned char i; 
    unsigned int crc_reg = 0; 
    unsigned int current; 
         
    while(len--) 
    { 
        current = *ptr << 8; 
        for (i = 0; i < 8; i++)  
        {  
            if ((crc_reg ^ current) & 0x8000) 
                crc_reg = (crc_reg << 1) ^ 0x1021; 
            else  
                crc_reg <<= 1;  

            current <<= 1;             
        } 
		ptr++;
    } 
    return crc_reg; 
}


int w_atoi (char *s)
{
	int i,n;
	for(n=0,i=0;s[i]!='\0';i++)
	{
		if(s[i] >= '0' && s[i] <= '9')
			n = 10*n + (s[i]-'0');
		else
			break;
	}
	return n;
}

#endif


