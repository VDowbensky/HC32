#ifndef __BSP_UART_H
#define __BSP_UART_H

#include "gpio.h"
#include "uart.h"
#include "lpuart.h"


void BSP_lpuart0_init(uint32_t baudrate);
void BSP_uart0_init(en_uart_baudrate_t baud);

void Hal_Uart0_Send(uint8_t c);
void Hal_Uart0_Send_Str(uint8_t *c);
uint8_t Hal_Uart0_Recv(uint8_t* c);

void Hal_LPUart0_Send(uint8_t c);
void Hal_LPUart0_Send_Str(uint8_t *c);
uint8_t Hal_LPUart0_Recv(uint8_t* c);

#endif

