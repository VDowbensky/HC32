#ifndef __IAP_H__
#define __IAP_H__

#include "flash.h"

#define  RESET_PWR_ON       0xff
#define  RESET_RSTB         0x80
#define  RESET_SOFT         0x40   

typedef  void (*iapfun)(void);				//定义一个函数类型参数

#define  DI()      { __disable_irq();  }
#define  EI()      { __enable_irq();   }

#define  MCU_SoftRest()      { NVIC_SystemReset(); }  

void iap_load_app(uint32_t appxaddr);

/*******************************************************************
移植的时候需要注意以下宏定义
1. 使用哪一个uart作为升级串口,以及波特率
2. 使用哪种触发方式升级(1. IO按键 2.flash写标志位)
3. 升级的app的起始地址
*******************************************************************/

//#define  TRIGGER_MOD_KEY     /*按键触发*/
//#define  TRIGGER_MOD_FLASH_FLG  /*app触发内部flash*/

#define  IAP_COM_UART0 
//#define  IAP_COM_UART1    
//#define  IAP_COM_LPUART0

#define  Sector125_BaseAddr (0xfa00)  /*用于记录iap跳转标志位*/


#if 0

#define  FLASH_IAP_CODE   0x55

#define  flash_IAP_startaddr  0xfa00/*the last 3 sector of 127(512bytes)*/

//#define FLASH_BOOT_SIZE    0x4000    // 16k 

void iap_load_app(uint32_t appxaddr);	//执行flash里的app程序

en_result_t  IAP_write_a_sertor(uint32_t startaddr,uint8_t *appbuf);

void IAP_start_check(void);


//extern unsigned char const acbt_timer[0x800];

/* nb 组包eventdata数据结构*/
typedef struct
{   
	char packbuff[1024];
	uint8_t  packbuffhex[512];
}ota_t;

extern ota_t OTA;

#endif

#endif







































