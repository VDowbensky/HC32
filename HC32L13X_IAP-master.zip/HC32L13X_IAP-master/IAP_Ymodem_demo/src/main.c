
/******************************************************************************/
/** \file main.c
 **
 ** A detailed description is available at
 ** @link Sample Group Some description @endlink
 **
 **   - 2018-03-09  1.0  Lux First version
 **
 ******************************************************************************/

#include "sysctrl.h"
#include "ddl.h"
#include "uart.h"
#include "gpio.h"
#include "flash.h"
#include "iap.h"
#include "Ymodem.h"
#include "bsp_uart.h"


int hclk = 0;

uint8_t	buff[516];
 
void Sysclk_Config_Init(void);

extern uint32_t	uTick ;

void Hal_Gpio_Init(void)
{
    stc_gpio_config_t 	stcGpioCfg;

    DDL_ZERO_STRUCT(stcGpioCfg);

    Sysctrl_SetPeripheralGate(SysctrlPeripheralGpio,TRUE);//

    //PD05=LED 
    stcGpioCfg.enDir = GpioDirOut;
    stcGpioCfg.enDrv = GpioDrvH;
    stcGpioCfg.enOD  = GpioOdDisable;
    stcGpioCfg.enPuPd= GpioPu;
    Gpio_Init(GpioPortD,GpioPin5,&stcGpioCfg);

    //PD04=User key
    stcGpioCfg.enDir = GpioDirIn;
    stcGpioCfg.enDrv = GpioDrvL;
    stcGpioCfg.enOD  = GpioOdDisable;
    stcGpioCfg.enPuPd= GpioPu;
    Gpio_Init(GpioPortD,GpioPin4,&stcGpioCfg);	
}


/*****************************************************************************
 * 使用内部或外部时钟，可供选择,但是在boot阶段,4Mhz内部时钟即可,避免app阶段增加功耗
 ******************************************************************************/
void Sysclk_Config_Init()
{	
	//	mcu_set_ext_hclk_32Mhz();		
	Sysctrl_SetRCH(SysctrlRchFreq24MHz);
	Sysctrl_SysClkSwitch(SysctrlClkRCH);
	Sysctrl_ClkSourceEnable(SysctrlClkRCL,TRUE);	
	SysTick_Config(SystemCoreClock / 1000U); /*1ms*/
	
} 


int main(void)
{
	uint32_t	len;
	uint32_t	timedelay;
	uint8_t		ch;
	
	Flash_Init(NULL,8,FALSE);	 	
	Flash_WaitCycle(FlashWaitCycle1);	
  	
#ifdef TRIGGER_MOD_KEY  

	Hal_Gpio_Init();
	
	if(Gpio_GetInputIO(GpioPortD,GpioPin4))	//User key not pressed ,jump to app
	{
       iap_load_app(APP_FW_START_ADDR);
	}
	
#endif

#ifdef TRIGGER_MOD_FLASH_FLG  

	uint8_t falsh_readout_dat = FLASH_Read(Sector125_BaseAddr);	

	if(falsh_readout_dat == 0xff)
	{
		iap_load_app(APP_FW_START_ADDR);
		
	}
	else
	{
		Flash_WriteByte(Sector125_BaseAddr, MCU.reset_cnt);
	}		
#endif


	Sysclk_Config_Init();	

    hclk = Sysctrl_GetHClkFreq(); 
  
	Hal_Gpio_Init();
	
	/*经过测试,2400 ~ 115200 都能100%升级*/
	BSP_uart0_init(UART9600);
	BSP_lpuart0_init(9600); /*Mbus Max is 9600*/
	
	__enable_irq();

	Hal_Uart0_Send_Str("Ymodem(128Bytes) Update Start Ready!.\r\n");
	Hal_Uart0_Send_Str("Please send the bin file to MCU.\r\n");

	Hal_LPUart0_Send_Str("Ymodem(128Bytes) Update Start Ready!.\r\n");
	Hal_LPUart0_Send_Str("Please send the bin file to MCU.\r\n");

	timedelay = uTick;
	
	while(1)
	{
		if((uTick - timedelay) > 1000)
		{
			timedelay = uTick; 
			//LED_TOG(); /*led toggle*/
		}	

		YModem_Receive_Proc(buff,&len);
#if 0		
		if(Hal_Uart0_Recv(&ch) == 0)
		{			
			if(ch == 'R')
			{
				YModem_Receive_Proc(buff,&len);
			}else if(ch == 'S')
			{
				YModem_Transmit((uint8_t *)(APP_FW_START_ADDR),"user.bin",1024*40); /* flash读出来用于调试*/
			}else
			{
				Hal_Uart0_Send(ch);	/* echo */			
			}
		}
#endif		
	}
}



