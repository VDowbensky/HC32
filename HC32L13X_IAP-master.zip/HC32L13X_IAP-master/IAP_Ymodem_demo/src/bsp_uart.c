#include "bsp_uart.h"

/*****************************************
PA09 -- UART0-TX
PA10 -- UART0-RX
*****************************************/
void BSP_uart0_init(en_uart_baudrate_t baud)
{	
	stc_uart_config_t	stcCfg;
	stc_gpio_config_t	stcGpioCfg;
	
	DDL_ZERO_STRUCT(stcGpioCfg);
	DDL_ZERO_STRUCT(stcCfg);
	
    Sysctrl_SetPeripheralGate(SysctrlPeripheralGpio,TRUE);  ///<使能GPIO外设时钟门控开关

    stcGpioCfg.enDir = GpioDirOut;
    Gpio_Init(GpioPortA,GpioPin9,&stcGpioCfg);
    Gpio_SetAfMode(GpioPortA,GpioPin9,GpioAf1);             ///<配置PA9 为UART0 TX
    stcGpioCfg.enDir = GpioDirIn;
    Gpio_Init(GpioPortA,GpioPin10,&stcGpioCfg);
    Gpio_SetAfMode(GpioPortA,GpioPin10,GpioAf1);             ///<配置PA10 为UART0 RX
	
    Sysctrl_SetPeripheralGate(SysctrlPeripheralUart0,TRUE); ///<使能UART0外设时钟门控开关
	
	//UART0 配置   
	stcCfg.enRunMode = UartMode1;  ///<模式1(奇偶校验位无效)
	stcCfg.BaudRate.enBaudRate = baud;
	stcCfg.enOver = Uart16Or32Div;
	//stcCfg.enParity = UartDataOrAddr;  /*无奇偶校验位*/
	stcCfg.enStopBit = Uart1bit;
	Uart_Init(0,&stcCfg);
		
}


/************************************************************************
 * 功能描述: 
 ***********************************************************************/
void Hal_Uart0_Send(uint8_t c)
{
    M0P_UART0->ICR_f.TCCF = 0;
    M0P_UART0->SBUF = c;
    while(M0P_UART0->ISR_f.TC == 0); 
    M0P_UART0->ICR_f.TCCF = 0;
}

void Hal_Uart0_Send_Str(uint8_t *c)
{
    while(*c != '\0')
	{
		Hal_Uart0_Send(*c++);
	}
}

uint8_t Hal_Uart0_Recv(uint8_t* c)
{
	uint32_t	tick = HAL_GetSysTick();
	
  	while(M0P_UART0->ISR_f.RC == 0)  /*RC = 1 : 接收完成*/
	{
		if((HAL_GetSysTick() - tick ) > 2)
		{
			return 1;
		}		
	}	
	*c = M0P_UART0->SBUF_f.DATA;
	M0P_UART0->ICR_f.RCCF = 0;	
	
	return	0;
}


void BSP_lpuart0_init(uint32_t baudrate)
{

	uint16_t u16Scnt = 0;
    stc_gpio_config_t stcGpioCfg;
    stc_lpuart_sclk_sel_t stcSclk;
    stc_lpuart_config_t  stcConfig;
    stc_lpuart_irq_cb_t stcLPUartIrqCb;
    stc_lpuart_multimode_t stcMulti;
    stc_lpuart_baud_t stcBaud;

    DDL_ZERO_STRUCT(stcConfig);
    DDL_ZERO_STRUCT(stcLPUartIrqCb);
    DDL_ZERO_STRUCT(stcMulti);
    DDL_ZERO_STRUCT(stcBaud);
    DDL_ZERO_STRUCT(stcGpioCfg);
    DDL_ZERO_STRUCT(stcSclk);
    
    Sysctrl_SetPeripheralGate(SysctrlPeripheralGpio,TRUE);//外设模式时钟使能
    Sysctrl_SetPeripheralGate(SysctrlPeripheralLpUart0,TRUE);
    
    ///<TX
    stcGpioCfg.enDir =  GpioDirOut;
    Gpio_Init(GpioPortB,GpioPin0,&stcGpioCfg);
    Gpio_SetAfMode(GpioPortB,GpioPin0,GpioAf3); //配置PB00为LPUART0_TX 
    //<RX
    stcGpioCfg.enDir =  GpioDirIn;
    Gpio_Init(GpioPortB,GpioPin11,&stcGpioCfg);
    Gpio_SetAfMode(GpioPortB,GpioPin11,GpioAf3); //配置PB11为LPUART0_RX
	
    stcConfig.enStopBit = LPUart1bit;//停止位
    stcConfig.enRunMode = LPUartMode3;//模式3
    stcSclk.enSclk_Prs = LPUart4Or8Div;//采样分频
    stcSclk.enSclk_sel =LPUart_Pclk;
    stcConfig.pstcLpuart_clk = &stcSclk;  
    
    stcMulti.enMulti_mode = LPUartNormal;
	LPUart_SetMultiMode(LPUART0,&stcMulti);//多机模式设置
  
    LPUart_SetMMDOrCk(LPUART0,LPUartEven);//偶校验
    LPUart_Init(LPUART0, &stcConfig);
    
    LPUart_SetClkDiv(LPUART0,LPUart4Or8Div);//采样分频
    
    stcBaud.u32Sclk = Sysctrl_GetPClkFreq();
    stcBaud.enRunMode = LPUartMode3;
    stcBaud.u32Baud = baudrate; 
    u16Scnt = LPUart_CalScnt(LPUART0,&stcBaud);//波特率计算
    LPUart_SetBaud(LPUART0,u16Scnt);//波特率值设置

    LPUart_EnableFunc(LPUART0,LPUartRx);//使能数据收发

}


void Hal_LPUart0_Send(uint8_t c)
{
//    M0P_LPUART0->ICR_f.TCCF = 0;
//    M0P_LPUART0->SBUF = c;
//    while(M0P_LPUART0->ISR_f.TC == 0); 
//    M0P_LPUART0->ICR_f.TCCF = 0;
	
	LPUart_SendData(LPUART0,c);
}

void Hal_LPUart0_Send_Str(uint8_t *c)
{
    while(*c != '\0')
	{
		Hal_LPUart0_Send(*c++);
	}
}

uint8_t Hal_LPUart0_Recv(uint8_t* c)
{
	uint32_t	tick = HAL_GetSysTick();	
	
  	while(M0P_LPUART0->ISR_f.RC == 0)  /*RC = 1 : 接收完成*/
	{
		if((HAL_GetSysTick() - tick ) > 2)
		{
			return 1;
		}		
	}	
	*c = M0P_LPUART0->SBUF_f.DATA;
	M0P_LPUART0->ICR_f.RCCF = 0;	
	return	0;
}



///<LPUART0 中断服务函数
void LpUart0_IRQHandler(void)
{
	
}


void LpUart0_SendString(uint8_t *buff, uint16_t lenth)
{	
	for( int i = 0; i < lenth; i++)
	{
		LPUart_SendData(0, buff[i]);//发送数据
	}		
}
  


//UART0中断
void Uart0_IRQHandler(void)
{
    if(Uart_GetStatus(0, UartRC))
    {
        Uart_ClrStatus(0, UartRC);              //清除中断状态位
        //u8RxData[u8RxCnt]=Uart_ReceiveData(M0P_UART1);  //发送数据
        //u8RxCnt++;
//        if(u8RxCnt>1)                                   //如果已接收两个字节
//        {
//            //Uart_DisableIrq(M0P_UART1,UartRxIrq);       //禁止接收中断
//        }
    }
}


