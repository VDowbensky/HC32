

#include "iapsub.h"

void MSR_MSP(unsigned  int addr);	//设置栈顶地址

//设置栈顶地址
//addr:栈顶地址
__asm void MSR_MSP(unsigned  int addr) 
{
    MSR MSP, r0 			//set Main Stack value
    BX r14
}







