#ifndef		FLASH_UPDATE__H_
#define		FLASH_UPDATE__H_


#include "flash.h"
#include "gpio.h"
                          
#define		LED_ON()      Gpio_SetIO(GpioPortD,GpioPin5)
#define		LED_OFF()     Gpio_ClrIO(GpioPortD,GpioPin5)
#define		LED_TOG()     M0P_GPIO->PDOUT ^= (1U << 5)

#define		APP_FW_INFO_ADDR			(0x00003000)
#define		APP_FW_START_ADDR			(0x00004000)  /*Ӧ�ó�����ʼ��ַ*/
#define		APP_FW_FLASH_SIZE			(1024*40)

typedef		void (*pFun)(void);

extern uint32_t UpdateAppCodeStart(uint8_t *filename,uint32_t filesize);
extern uint32_t UpdateAppCode(uint8_t *buff);
extern uint32_t UpdateAppCodeEnd(uint8_t *buff, uint32_t len);

#endif	//	



