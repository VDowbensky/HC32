#ifndef __IAPSUB_H__
#define __IAPSUB_H__

#include <stdbool.h>

void MSR_MSP(unsigned  int addr);	//���ö�ջ��ַ

#endif







































