/*************************************************************************************
* Copyright (C) 2017, Huada Semiconductor Co.,Ltd All rights reserved.    
*
* This software is owned and published by: 
* Huada Semiconductor Co.,Ltd ("HDSC").
*
* BY DOWNLOADING, INSTALLING OR USING THIS SOFTWARE, YOU AGREE TO BE BOUND 
* BY ALL THE TERMS AND CONDITIONS OF THIS AGREEMENT.
*
* This software contains source code for use with HDSC 
* components. This software is licensed by HDSC to be adapted only 
* for use in systems utilizing HDSC components. HDSC shall not be 
* responsible for misuse or illegal use of this software for devices not 
* supported herein. HDSC is providing this software "AS IS" and will 
* not be responsible for issues arising from incorrect user implementation 
* of the software.  
*
* Disclaimer:
* HDSC MAKES NO WARRANTY, EXPRESS OR IMPLIED, ARISING BY LAW OR OTHERWISE,
* REGARDING THE SOFTWARE (INCLUDING ANY ACOOMPANYING WRITTEN MATERIALS), 
* ITS PERFORMANCE OR SUITABILITY FOR YOUR INTENDED USE, INCLUDING, 
* WITHOUT LIMITATION, THE IMPLIED WARRANTY OF MERCHANTABILITY, THE IMPLIED 
* WARRANTY OF FITNESS FOR A PARTICULAR PURPOSE OR USE, AND THE IMPLIED 
* WARRANTY OF NONINFRINGEMENT.  
* HDSC SHALL HAVE NO LIABILITY (WHETHER IN CONTRACT, WARRANTY, TORT, 
* NEGLIGENCE OR OTHERWISE) FOR ANY DAMAGES WHATSOEVER (INCLUDING, WITHOUT 
* LIMITATION, DAMAGES FOR LOSS OF BUSINESS PROFITS, BUSINESS INTERRUPTION, 
* LOSS OF BUSINESS INFORMATION, OR OTHER PECUNIARY LOSS) ARISING FROM USE OR 
* INABILITY TO USE THE SOFTWARE, INCLUDING, WITHOUT LIMITATION, ANY DIRECT, 
* INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OR LOSS OF DATA, 
* SAVINGS OR PROFITS, 
* EVEN IF Disclaimer HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. 
* YOU ASSUME ALL RESPONSIBILITIES FOR SELECTION OF THE SOFTWARE TO ACHIEVE YOUR
* INTENDED RESULTS, AND FOR THE INSTALLATION OF, USE OF, AND RESULTS OBTAINED 
* FROM, THE SOFTWARE.  
*
* This software may be replicated in part or whole for the licensed use, 
* with the restriction that this Disclaimer and Copyright notice must be 
* included with each copy of this software, whether used in part or whole, 
* at all times.                        
*/
/******************************************************************************/
/** \file uart.c
 **
 ** UART function driver API.
 ** @link SampleGroup Some description @endlink
 **
 **   - 2017-05-17  1.0  CJ First version for Device Driver Library of Module.
 **
 ******************************************************************************/

/******************************************************************************/
/* Include files                                                              */
/******************************************************************************/
#include "uart.h"
/**
 ******************************************************************************
 ** \addtogroup UartGroup
 ******************************************************************************/
//@{
/******************************************************************************/
/* Local pre-processor symbols/macros ('#define')                             */
/******************************************************************************/

#define IS_VALID_CH(x)          ((UARTCH0 == (x)) ||\
                                 (UARTCH1 == (x)))


#define IS_VALID_MODE(x)        ((UartMode0==(x))||\
                                 (UartMode1==(x))||\
                                 (UartMode2==(x))||\
                                 (UartMode3==(x)))

#define IS_VALID_STATUS(x)      ((UartCts == (x))||\
                                 (UartRC == (x))||\
                                 (UartTC == (x))||\
                                 (UartPE == (x))||\
                                 (UartCtsIf == (x))||\
                                 (UartTxe == (x))||\
                                 (UartFE == (x)))
/******************************************************************************/
/* Local function prototypes ('static')                                       */
/******************************************************************************/
static stc_uart_instance_data_t* UartGetInternDataPtr(uint8_t u8Idx);
/******************************************************************************/
/* Local variable definitions ('static')                                       */
/******************************************************************************/
__WEAKDEF void Uart0_Tx_ISR(void)
{

}
__WEAKDEF void Uart0_RxFE_ISR(void)
{

}
__WEAKDEF void Uart0_Rx_ISR(void)
{

}
__WEAKDEF void Uart0_CTS_ISR(void)
{

}
__WEAKDEF void Uart0_PE_ISR(void)
{

}

__WEAKDEF void Uart1_Tx_ISR(void)
{

}
__WEAKDEF void Uart1_RxFE_ISR(void)
{

}
__WEAKDEF void Uart1_Rx_ISR(void)
{

}
__WEAKDEF void Uart1_CTS_ISR(void)
{

}
__WEAKDEF void Uart1_PE_ISR(void)
{

}

static stc_uart_instance_data_t m_astcUartInstanceDataLut[] =
{
    {
        UARTCH0,
        M0P_UART0,       /* pstcInstance */
       {
	   Uart0_Tx_ISR,
	   Uart0_RxFE_ISR,
	   Uart0_Rx_ISR,
	   Uart0_CTS_ISR,
	   Uart0_PE_ISR
	   },     
    },
    {
        UARTCH1,
        M0P_UART1,       /* pstcInstance */
       {
	   Uart1_Tx_ISR,
	   Uart1_RxFE_ISR,
	   Uart1_Rx_ISR,
	   Uart1_CTS_ISR,
	   Uart1_PE_ISR
	   },    
    },
};
/**
 ******************************************************************************
 ** \brief  UART0/1通道 相关地址获取
 **
 ** \param [in] u8Idx通道号
 **
 ** \retval 通道对应的地址结构
 **
 ******************************************************************************/
static stc_uart_instance_data_t* UartGetInternDataPtr(uint8_t u8Idx)
{
    stc_uart_instance_data_t* pstcData = NULL;
    uint8_t u8i = 0;
    for (u8i = 0; u8i < ARRAY_SZ(m_astcUartInstanceDataLut); u8i++)
    {
        if (u8Idx == m_astcUartInstanceDataLut[u8i].u32Idx)
        {
            pstcData = &m_astcUartInstanceDataLut[u8i];
            break;
        }
    }

    return (pstcData);
}
/**
 ******************************************************************************
 ** \brief  UART通信中断使能函数设置
 **
 ** \param [in] u8Idx通道号，enIrqSel发送or接收中断使能
 **
 ** \retval OK配置成功
 **\retval ErrorInvalidParameter配置失败
 ******************************************************************************/
en_result_t Uart_SetIrq(uint8_t u8Idx, uint32_t IrqFlag)
{
    stc_uart_instance_data_t* pstcData = NULL;
	
    ASSERT(IS_VALID_CH(u8Idx));
	
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;
    }
	
	if(IrqFlag & UartTxIrq)
	{
			pstcData->pstcInstance->SCON_f.TCIE  = 1u;
	}else
	{
			pstcData->pstcInstance->SCON_f.TCIE  = 0u;
	}
	
	if(IrqFlag & UartRxIrq)
	{
			pstcData->pstcInstance->SCON_f.RCIE  = 1u;
	}else
	{
			pstcData->pstcInstance->SCON_f.RCIE  = 0u;
	}
	if(IrqFlag & UartFEIrq)
	{
			pstcData->pstcInstance->SCON_f.FEIE  = 1u;
	}else
	{
			pstcData->pstcInstance->SCON_f.FEIE  = 0u;
	}
	if(IrqFlag & UartCtsIrq)
	{
			pstcData->pstcInstance->SCON_f.CTSIE = 1u;
	}else
	{
			pstcData->pstcInstance->SCON_f.CTSIE = 0u;
	}
	if(IrqFlag & UartPEIrq)
	{
			pstcData->pstcInstance->SCON_f.PEIE  = 1u;
	}else
	{
			pstcData->pstcInstance->SCON_f.PEIE  = 0u;
	}	
	if(IrqFlag & UartTxEIrq)
	{
			pstcData->pstcInstance->SCON_f.TXEIE = 1u;
	}else
	{
			pstcData->pstcInstance->SCON_f.TXEIE = 0u;
	}	
	
    return Ok;
}

/**
 ******************************************************************************
 ** \brief 获取RB8数值
 **
 ** \param [in] u8Idx通道号
 **
 ** \retval RB8
 **\retval ErrorInvalidParameter配置失败
 ******************************************************************************/
boolean_t Uart_GetRb8(uint8_t u8Idx)
{
     stc_uart_instance_data_t *pstcData = NULL;
    ASSERT(IS_VALID_CH(u8Idx));
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;
    }
    return (pstcData->pstcInstance->SBUF_f.DATA8);
}
/**
 ******************************************************************************
 ** \brief  UART通道多主机模式从机地址配置函数
 **
 ** \param [in] u8Idx通道号，addr地址
 **
 ** \retval OK配置成功
 **\retval ErrorInvalidParameter配置失败
 ******************************************************************************/
en_result_t Uart_SetSaddr(uint8_t u8Idx,uint8_t u8Addr)
{
    stc_uart_instance_data_t *pstcData = NULL;
    ASSERT(IS_VALID_CH(u8Idx));
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;
    }
    pstcData->pstcInstance->SADDR = u8Addr;
    return Ok;
}
/**
 ******************************************************************************
 ** \brief  UART通道多主机模式从机掩码配置函数
 **
 ** \param [in] u8Idx通道号，addren地址掩码
 **
 ** \retval OK配置成功
 **\retval ErrorInvalidParameter配置失败
 ******************************************************************************/
en_result_t Uart_SetSaddrEn(uint8_t u8Idx,uint8_t u8Addren)
{
    stc_uart_instance_data_t *pstcData = NULL;
    ASSERT(IS_VALID_CH(u8Idx));
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;
    }
    pstcData->pstcInstance->SADEN = u8Addren;
    return Ok;  
}

/**
 ******************************************************************************
 ** \brief  UART通道发送或接收等功能使能设置
 **
 ** \param [in] u8Idx通道号，enFunc功能
 **
 ** \retval OK配置成功
 **\retval ErrorInvalidParameter配置失败
 ******************************************************************************/
en_result_t Uart_EnableFunc(uint8_t u8Idx, en_uart_func_t enFunc)
{
    stc_uart_instance_data_t *pstcData = NULL;
    ASSERT(IS_VALID_CH(u8Idx));
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;
    }
    switch(enFunc)
    {
        case UartTx:
        case UartRx:
            pstcData->pstcInstance->SCON_f.REN = 1u;
            break;
        case UartDmaTx:
            pstcData->pstcInstance->SCON_f.DMATXEN = 1u;
            break;
        case UartDmaRx:
            pstcData->pstcInstance->SCON_f.DMARXEN = 1u;
            break;
        case UartCtsRts:
            pstcData->pstcInstance->SCON_f.CTSEN = 1u;
            pstcData->pstcInstance->SCON_f.RTSEN = 1u;
            break;
        default:
            return ErrorInvalidParameter;
    }
    return Ok;
}
/**
 ******************************************************************************
 ** \brief  UART通道发送或接收等功能禁止设置
 **
 ** \param [in] u8Idx通道号，enFunc功能
 **
 ** \retval OK配置成功
 **\retval ErrorInvalidParameter配置失败
 ******************************************************************************/
en_result_t Uart_DisableFunc(uint8_t u8Idx, en_uart_func_t enFunc)
{
    stc_uart_instance_data_t *pstcData = NULL;
    ASSERT(IS_VALID_CH(u8Idx));
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;
    }
    switch(enFunc)
    {
        case UartTx:
        case UartRx:
            pstcData->pstcInstance->SCON_f.REN = 0u;
            break;
        case UartDmaTx:
            pstcData->pstcInstance->SCON_f.DMATXEN = 0u;
            break;
        case UartDmaRx:
            pstcData->pstcInstance->SCON_f.DMARXEN = 0u;
            break;
        case UartCtsRts:
            pstcData->pstcInstance->SCON_f.CTSEN = 0u;
            pstcData->pstcInstance->SCON_f.RTSEN = 0u;
            break;
        default:
            return ErrorInvalidParameter;
    }
    return Ok;
}
/**
 ******************************************************************************
 ** \brief  UART通道通信状态获取
 **
 ** \param [in] u8Idx通道号
 **
 ** \retval 状态值
 ******************************************************************************/
uint8_t Uart_GetIsr(uint8_t u8Idx)
{
    stc_uart_instance_data_t *pstcData = NULL;
    ASSERT(IS_VALID_CH(u8Idx));
    pstcData = UartGetInternDataPtr(u8Idx);
    return (pstcData->pstcInstance->ISR);
}
/**
 ******************************************************************************
 ** \brief  UART通道通信状态获取
 **
 ** \param [in] u8Idx通道号，enStatus获取哪个状态
 **
 ** \retval 状态值
 **\retval ErrorInvalidParameter获取失败
 ******************************************************************************/
boolean_t Uart_GetStatus(uint8_t u8Idx,en_uart_status_t enStatus)
{
    boolean_t bStatus=FALSE;
    stc_uart_instance_data_t *pstcData = NULL;
    ASSERT(IS_VALID_CH(u8Idx));
    ASSERT(IS_VALID_STATUS(enStatus));
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;//4，用户只需判断0或1
    }
    switch(enStatus)
    {
        case UartCts:
            bStatus = (pstcData->pstcInstance->ISR_f.CTS == 1) ? TRUE : FALSE;
            break;
        case UartRC:
            bStatus = (pstcData->pstcInstance->ISR_f.RC == 1) ? TRUE : FALSE;
            break;
        case UartTC:
            bStatus = (pstcData->pstcInstance->ISR_f.TC == 1) ? TRUE : FALSE;
            break;
        case UartPE:
            bStatus = (pstcData->pstcInstance->ISR_f.PE == 1) ? TRUE : FALSE;
            break;
        case UartFE:
            bStatus = (pstcData->pstcInstance->ISR_f.FE == 1) ? TRUE : FALSE;
            break;
        case UartCtsIf:
            bStatus = (pstcData->pstcInstance->ISR_f.CTSIF == 1) ? TRUE : FALSE;
            break;
        case UartTxe:
            bStatus = (pstcData->pstcInstance->ISR_f.TXE == 1) ? TRUE : FALSE;
            break;
        default:
            break; 
    }
    return bStatus;
}
/**
 ******************************************************************************
 ** \brief  UART通道通信状态清除
 **
 ** \param [in] u8Idx通道号
 **
 ** \retval OK
 ******************************************************************************/
en_result_t Uart_ClrIsr(uint8_t u8Idx)
{
    stc_uart_instance_data_t *pstcData = NULL;
    ASSERT(IS_VALID_CH(u8Idx));
    pstcData = UartGetInternDataPtr(u8Idx);
    pstcData->pstcInstance->ICR = 0u;
    return Ok;
}
/**
 ******************************************************************************
 ** \brief  UART通道通信状态清除
 **
 ** \param [in] u8Idx通道号，enStatus清除哪个状态
 **
 ** \retval 状态值
 **\retval ErrorInvalidParameter清除失败
 ******************************************************************************/
en_result_t Uart_ClrStatus(uint8_t u8Idx,en_uart_status_t enStatus)
{
    stc_uart_instance_data_t *pstcData = NULL;
    ASSERT(IS_VALID_CH(u8Idx));
    ASSERT(IS_VALID_STATUS(enStatus));
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;
    }
    switch(enStatus)
    {
        case UartCts:
            pstcData->pstcInstance->ICR_f.CTSIFCF = 0;
            break;
        case UartRC:
            pstcData->pstcInstance->ICR_f.RCCF = 0;
            break;
        case UartTC:
            pstcData->pstcInstance->ICR_f.TCCF = 0;
            break;
        case UartPE:
            pstcData->pstcInstance->ICR_f.PECF = 0;
            break;
        case UartFE:
            pstcData->pstcInstance->ICR_f.FECF = 0;
            break;   
        default:
            break; 
    }
    return Ok;
}
/**
 ******************************************************************************
 ** \brief  UART通道发送数据函数,查询方式调用此函数，中断方式发送不适用
 **
 ** \param [in] u8Idx通道号，Data发送数据
 **
 ** \retval Ok发送成功
 **\retval ErrorInvalidParameter发送失败
 ******************************************************************************/
en_result_t Uart_SendData(uint8_t u8Idx, uint8_t u8Data)
{
    stc_uart_instance_data_t *pstcData = NULL;
	
    ASSERT(IS_VALID_CH(u8Idx));
	
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;
    }
		
    Uart_ClrStatus(u8Idx,UartTC);
		
    pstcData->pstcInstance->SBUF_f.DATA = u8Data;
    while(FALSE == Uart_GetStatus(u8Idx,UartTC)){}
    Uart_ClrStatus(u8Idx,UartTC);    
			
    return Ok;
}
/**
 ******************************************************************************
 ** \brief  UART通道接收数据函数
 **
 ** \param [in] u8Idx通道号
 **
 ** \retval 接收数据
 **\retval ErrorInvalidParameter接收失败
 ******************************************************************************/
uint8_t Uart_ReceiveData(uint8_t u8Idx)
{
    stc_uart_instance_data_t *pstcData = NULL;
	
    ASSERT(IS_VALID_CH(u8Idx));
	
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;
    }
    return (pstcData->pstcInstance->SBUF_f.DATA);
}
/**
 ******************************************************************************
 ** \brief  UART通道中断处理函数
 **
 ** \param [in] u8Param通道号
 **
 ** \retval 无
 **
 ******************************************************************************/
void Uart_IRQHandler(uint8_t u8Param)
{
    stc_uart_instance_data_t *pstcData = NULL;
    pstcData = UartGetInternDataPtr(u8Param);
    if (NULL == pstcData)
    {
        return;
    }
    if(1 == pstcData->pstcInstance->ISR_f.FE)
    {
        Uart_ClrStatus(u8Param,UartFE);
        if(NULL != pstcData->stcUartInternIrqCb.pfnRxFEIrqCb)
        {
            pstcData->stcUartInternIrqCb.pfnRxFEIrqCb();
        }
        return;//帧出错则不进行后续数据处理
    }
    if(1 == pstcData->pstcInstance->ISR_f.PE)
    {
        Uart_ClrStatus(u8Param,UartPE);
        if(NULL != pstcData->stcUartInternIrqCb.pfnPEIrqCb)
        {
            pstcData->stcUartInternIrqCb.pfnPEIrqCb();
        }
        return;//若奇偶校验出错则不进行后续数据处理
    }
    if(1 == pstcData->pstcInstance->ISR_f.CTSIF)
    {
        Uart_ClrStatus(u8Param,UartCts);
        if(NULL != pstcData->stcUartInternIrqCb.pfnCtsIrqCb)
        {
            pstcData->stcUartInternIrqCb.pfnCtsIrqCb();
        }
    }
    if(1 == pstcData->pstcInstance->ISR_f.RC)
    {
        Uart_ClrStatus(u8Param,UartRC);
        if(NULL != pstcData->stcUartInternIrqCb.pfnRxIrqCb)
        {
            pstcData->stcUartInternIrqCb.pfnRxIrqCb();
        }
    }
    if(1 == pstcData->pstcInstance->ISR_f.TC)
    {
        Uart_ClrStatus(u8Param,UartTC);
        if(NULL != pstcData->stcUartInternIrqCb.pfnTxIrqCb)
        {
            pstcData->stcUartInternIrqCb.pfnTxIrqCb();
        }
    }
}

/**
 ******************************************************************************
 ** \brief  UART通道初始化函数
 **
 ** \param [in] u8Idx通道号，pstcConfig初始化结构体
 **
 ** \retval OK配置成功
 **\retval ErrorInvalidParameter配置失败
 ******************************************************************************/
en_result_t Uart_Init(uint8_t u8Idx, stc_uart_config_t* pstcConfig)
{
	uint32_t			u32Baud;	
    en_result_t 	enRet = Error;

    stc_uart_instance_data_t *pstcData = NULL;
	
    ASSERT(IS_VALID_CH(u8Idx));
	
    pstcData = UartGetInternDataPtr(u8Idx);
    if (NULL == pstcData)
    {
        return ErrorInvalidParameter;
    }
    if(NULL == pstcConfig)
    {
        return ErrorInvalidParameter;
    }
		
    pstcData->pstcInstance->SCON_f.SM = pstcConfig->enRunMode;
	pstcData->pstcInstance->SCON_f.OVER = pstcConfig->enOver;
	pstcData->pstcInstance->SCON_f.B8CONT = pstcConfig->enParity;
	pstcData->pstcInstance->SCON_f.STOPBIT =  pstcConfig->enStopBit;
	pstcData->pstcInstance->SCON_f.REN  = 1;	//发送接收			
	switch(pstcConfig->enRunMode)
    {
        case UartMode0:					
            u32Baud = Sysctrl_GetPClkFreq()/12;
			pstcConfig->BaudRate.BaudClk = u32Baud;
            break;
        case UartMode1:
        case UartMode3:
            if(0 == pstcData->pstcInstance->SCON_f.OVER)
            {
				u32Baud = Sysctrl_GetPClkFreq()/(pstcConfig->BaudRate.enBaudRate << 4);
            }else
            {
                u32Baud = Sysctrl_GetPClkFreq()/(pstcConfig->BaudRate.enBaudRate << 3);
            }
            pstcData->pstcInstance->SCNT = u32Baud;
						
            break;
        case UartMode2:
            if(0 == pstcData->pstcInstance->SCON_f.OVER)
            {
				u32Baud = Sysctrl_GetPClkFreq()/32;
            }
            else
            {
                u32Baud = Sysctrl_GetPClkFreq()/16;
            }
            pstcConfig->BaudRate.BaudClk = u32Baud;
            break;
        default :
          return ErrorInvalidParameter;
    }
	pstcData->pstcInstance->ICR = 0u;	//Clear flag
	Uart_SetIrq(u8Idx, pstcConfig->IRQFlag);		
		
    pstcData->pstcInstance->SCON_f.ADRDET = pstcConfig->sMultimode.enMulti_mode;
    if( pstcConfig->sMultimode.enMulti_mode == UartMulti)
    {
        pstcData->pstcInstance->SADDR = pstcConfig->sMultimode.u8SlaveAddr;
        pstcData->pstcInstance->SADEN = pstcConfig->sMultimode.u8SaddEn;
    }

    enRet = Ok;
    return enRet;
}
//@} // UartGroup      
