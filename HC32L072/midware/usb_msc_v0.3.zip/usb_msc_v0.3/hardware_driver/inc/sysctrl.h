
#include "hc32l176.h"

extern void systemClock_rch(uint8_t fr);
extern void systemClock_xth(void);
extern void systemClock_pllcfg(uint8_t time);


