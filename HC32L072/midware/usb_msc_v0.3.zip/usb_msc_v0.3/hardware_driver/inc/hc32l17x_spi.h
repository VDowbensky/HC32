
#ifndef  __HC32L17X_SPI_H__
#define  __HC32L17X_SPI_H__

#include "hc32l176.h"


#endif





